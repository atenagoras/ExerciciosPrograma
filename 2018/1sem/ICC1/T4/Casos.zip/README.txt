Arquivo zip gerado em: 16/06/2018 18:55:39 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 4 - Escalonamento, Retas e Planos (conjunto com GA)